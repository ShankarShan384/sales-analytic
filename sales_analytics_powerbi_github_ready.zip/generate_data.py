"""Generate SYNTHETIC sales/quotation data for the Power BI star-schema project.
All names, prices and quantities are made up for practice. No real company data.
Run: python generate_data.py   (seeded, so output is repeatable)"""
import csv, random, datetime as dt
random.seed(42)

# ---------- dim_date ----------
start, end = dt.date(2026, 1, 1), dt.date(2026, 12, 31)
dates = []
d = start
while d <= end:
    dates.append(d)
    d += dt.timedelta(days=1)
def dkey(x): return int(x.strftime("%Y%m%d"))
with open("data/dim_date.csv", "w", newline="") as f:
    w = csv.writer(f, lineterminator="\n")
    w.writerow(["date_key", "full_date", "year", "quarter", "month_num", "month_name", "day_name"])
    for x in dates:
        w.writerow([dkey(x), x.isoformat(), x.year, (x.month - 1)//3 + 1, x.month, x.strftime("%B"), x.strftime("%A")])

# ---------- dim_status ----------
statuses = [(1, "Pending"), (2, "In Production"), (3, "Delivered"), (4, "Cancelled")]
with open("data/dim_status.csv", "w", newline="") as f:
    w = csv.writer(f, lineterminator="\n"); w.writerow(["status_id", "status_name"]); w.writerows(statuses)

# ---------- dim_product ----------
mats = {"GI Sheet": [(0.5, 1450), (0.8, 2150), (1.0, 2650)],
        "Galvalume Sheet": [(0.5, 1650), (0.8, 2400), (1.0, 2950)],
        "Stainless Steel Sheet": [(0.8, 5200), (1.0, 6400), (1.2, 7600)],
        "Aluminium Sheet": [(0.8, 3100), (1.0, 3800), (1.5, 5200)]}
products = []
pid = 1
for m, rows in mats.items():
    for th, price in rows:
        products.append((pid, f"{m} {th}mm", m, th, price)); pid += 1
with open("data/dim_product.csv", "w", newline="") as f:
    w = csv.writer(f, lineterminator="\n")
    w.writerow(["product_id", "product_name", "material", "thickness_mm", "unit_price_per_sheet"])
    w.writerows(products)

# ---------- dim_customer ----------
pre = ["Sri Murugan", "Vel", "Annai", "Lakshmi", "Balaji", "Kaveri", "Ganesh", "Thamarai", "Surya", "Arun",
       "Karthik", "Meenakshi", "Chola", "Pandian", "Nilgiri", "Bharath", "Sakthi", "Ezhil"]
suf = ["Constructions", "Roofing Works", "Builders", "Steel Traders", "Engineering", "Infra", "Agencies"]
names = random.sample([f"{p} {s}" for p in pre for s in suf], 40)
types = ["Contractor", "Builder", "Dealer", "Individual"]
cities = ["Chennai", "Tiruvallur", "Kanchipuram", "Chengalpattu", "Vellore"]
customers = [(i + 1, n, random.choices(types, [4, 3, 2, 1])[0], random.choices(cities, [5, 2, 2, 2, 1])[0])
             for i, n in enumerate(names)]
with open("data/dim_customer.csv", "w", newline="") as f:
    w = csv.writer(f, lineterminator="\n")
    w.writerow(["customer_id", "customer_name", "customer_type", "city"]); w.writerows(customers)

# customers get uneven popularity so "top customer" analysis is meaningful
weights = [random.paretovariate(1.4) for _ in customers]
prod_w = [5, 6, 3, 4, 5, 3, 1, 1, 1, 2, 2, 1]
GST = 0.18

# ---------- fact_quotations ----------
quotes = []
qid = 1
day = start
q_dates = [start + dt.timedelta(days=i) for i in range(0, (dt.date(2026, 9, 30) - start).days + 1)]
for _ in range(320):
    qd = random.choice(q_dates)
    cust = random.choices(customers, weights)[0]
    prod = random.choices(products, prod_w)[0]
    qty = max(5, int(random.lognormvariate(3.6, 0.7)))
    price = prod[4]
    value = round(qty * price * (1 + GST), 2)
    quotes.append([qid, dkey(qd), qd, cust[0], prod[0], qty, price, GST, value, 0])
    qid += 1
quotes.sort(key=lambda r: (r[1], r[0]))
for i, r in enumerate(quotes): r[0] = i + 1

# ---------- fact_orders ----------
orders = []
oid = 1
def status_for(od):
    if od < dt.date(2026, 8, 1):
        return random.choices([3, 4, 2], [90, 6, 4])[0]
    if od < dt.date(2026, 9, 15):
        return random.choices([3, 2, 1, 4], [45, 35, 15, 5])[0]
    return random.choices([2, 1, 3, 4], [45, 40, 10, 5])[0]
def make_order(qrow, od, cust_id, prod_id, qty, price):
    global oid
    disc = random.choice([0, 0, 2, 3, 5])
    net = round(qty * price * (1 - disc / 100), 2)
    gst_amt = round(net * GST, 2)
    orders.append([oid, qrow[0] if qrow else "", dkey(od), cust_id, prod_id, status_for(od), qty, price, disc, GST,
                   net, gst_amt, round(net + gst_amt, 2)])
    oid += 1
for q in quotes:
    if random.random() < 0.52:           # ~52% of quotations convert
        q[9] = 1
        od = q[2] + dt.timedelta(days=random.randint(1, 14))
        make_order(q, od, q[3], q[4], q[5], q[6])
for _ in range(35):                       # walk-in / repeat orders with no quotation
    od = random.choice(q_dates) + dt.timedelta(days=random.randint(0, 5))
    cust = random.choices(customers, weights)[0]
    prod = random.choices(products, prod_w)[0]
    make_order(None, od, cust[0], prod[0], max(5, int(random.lognormvariate(3.4, 0.6))), prod[4])
orders.sort(key=lambda r: (r[2], r[0]))
for i, r in enumerate(orders): r[0] = i + 1
# re-map quotation ids after sorting (they were fixed before orders were made, so safe)

with open("data/fact_quotations.csv", "w", newline="") as f:
    w = csv.writer(f, lineterminator="\n")
    w.writerow(["quotation_id", "quotation_date_key", "customer_id", "product_id", "quantity_sheets",
                "unit_price", "gst_rate", "quotation_value", "converted_flag"])
    for r in quotes: w.writerow([r[0], r[1], r[3], r[4], r[5], r[6], r[7], r[8], r[9]])
with open("data/fact_orders.csv", "w", newline="") as f:
    w = csv.writer(f, lineterminator="\n")
    w.writerow(["order_id", "quotation_id", "order_date_key", "customer_id", "product_id", "status_id",
                "quantity_sheets", "unit_price", "discount_pct", "gst_rate", "net_amount", "gst_amount", "total_amount"])
    w.writerows(orders)
print(len(quotes), "quotations,", len(orders), "orders")
