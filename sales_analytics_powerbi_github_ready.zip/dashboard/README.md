# Dashboard

`dashboard_preview.png` is a dashboard preview generated from the supplied synthetic dataset.

For a fully native Power BI deliverable, import the six CSV tables into Power BI Desktop, create the documented star-schema relationships, add `dax/measures.dax`, and reproduce this page. The preview is intentionally labelled as a preview and is not presented as a `.pbix` screenshot.
