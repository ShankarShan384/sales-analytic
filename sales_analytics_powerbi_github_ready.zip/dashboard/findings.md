# Dashboard findings

- Peak revenue month: September with ₹4,622,479.50.
- Total non-cancelled revenue: ₹26,029,552.00 across 198 orders.
- Average order value: ₹131,462.38.
- Quotation conversion rate: 53.1%.
- Top customer by revenue: Balaji Constructions (15.5% of total non-cancelled revenue).
- Highest-revenue material: GI Sheet.
