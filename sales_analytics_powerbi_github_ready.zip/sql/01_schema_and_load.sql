-- =====================================================================
-- Manufacturing Sales & Quotation Analytics: MySQL schema + data load
-- Star schema: 2 fact tables (orders, quotations) + 4 dimensions
-- Data is SYNTHETIC (see generate_data.py). Tested for MySQL 8.0+.
-- =====================================================================
DROP DATABASE IF EXISTS sales_analytics;
CREATE DATABASE sales_analytics;
USE sales_analytics;

-- ---------- Dimensions ----------
CREATE TABLE dim_date (
    date_key     INT PRIMARY KEY,            -- yyyymmdd
    full_date    DATE NOT NULL,
    year         SMALLINT NOT NULL,
    quarter      TINYINT NOT NULL,
    month_num    TINYINT NOT NULL,
    month_name   VARCHAR(12) NOT NULL,
    day_name     VARCHAR(12) NOT NULL
);

CREATE TABLE dim_status (
    status_id    TINYINT PRIMARY KEY,
    status_name  VARCHAR(20) NOT NULL
);

CREATE TABLE dim_product (
    product_id           INT PRIMARY KEY,
    product_name         VARCHAR(60) NOT NULL,
    material             VARCHAR(40) NOT NULL,
    thickness_mm         DECIMAL(3,1) NOT NULL,
    unit_price_per_sheet DECIMAL(10,2) NOT NULL
);

CREATE TABLE dim_customer (
    customer_id    INT PRIMARY KEY,
    customer_name  VARCHAR(80) NOT NULL,
    customer_type  VARCHAR(20) NOT NULL,
    city           VARCHAR(40) NOT NULL
);

-- ---------- Facts ----------
CREATE TABLE fact_quotations (
    quotation_id        INT PRIMARY KEY,
    quotation_date_key  INT NOT NULL,
    customer_id         INT NOT NULL,
    product_id          INT NOT NULL,
    quantity_sheets     INT NOT NULL,
    unit_price          DECIMAL(10,2) NOT NULL,
    gst_rate            DECIMAL(4,2) NOT NULL,
    quotation_value     DECIMAL(14,2) NOT NULL,   -- incl. GST
    converted_flag      TINYINT NOT NULL,         -- 1 = became an order
    FOREIGN KEY (quotation_date_key) REFERENCES dim_date(date_key),
    FOREIGN KEY (customer_id)        REFERENCES dim_customer(customer_id),
    FOREIGN KEY (product_id)         REFERENCES dim_product(product_id)
);

CREATE TABLE fact_orders (
    order_id         INT PRIMARY KEY,
    quotation_id     INT NULL,                    -- NULL = walk-in / repeat order
    order_date_key   INT NOT NULL,
    customer_id      INT NOT NULL,
    product_id       INT NOT NULL,
    status_id        TINYINT NOT NULL,
    quantity_sheets  INT NOT NULL,
    unit_price       DECIMAL(10,2) NOT NULL,
    discount_pct     DECIMAL(4,1) NOT NULL,
    gst_rate         DECIMAL(4,2) NOT NULL,
    net_amount       DECIMAL(14,2) NOT NULL,      -- after discount, before GST
    gst_amount       DECIMAL(14,2) NOT NULL,
    total_amount     DECIMAL(14,2) NOT NULL,      -- net + GST
    FOREIGN KEY (quotation_id)   REFERENCES fact_quotations(quotation_id),
    FOREIGN KEY (order_date_key) REFERENCES dim_date(date_key),
    FOREIGN KEY (customer_id)    REFERENCES dim_customer(customer_id),
    FOREIGN KEY (product_id)     REFERENCES dim_product(product_id),
    FOREIGN KEY (status_id)      REFERENCES dim_status(status_id)
);

-- ---------- Load CSVs ----------
-- Run from the project folder. If you get error 3948 / 1290, enable local_infile:
--   SET GLOBAL local_infile = 1;   and connect with:  mysql --local-infile=1 -u root -p
-- Or use MySQL Workbench > Table Data Import Wizard instead.
LOAD DATA LOCAL INFILE 'data/dim_date.csv' INTO TABLE dim_date
    FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' IGNORE 1 LINES;
LOAD DATA LOCAL INFILE 'data/dim_status.csv' INTO TABLE dim_status
    FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' IGNORE 1 LINES;
LOAD DATA LOCAL INFILE 'data/dim_product.csv' INTO TABLE dim_product
    FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' IGNORE 1 LINES;
LOAD DATA LOCAL INFILE 'data/dim_customer.csv' INTO TABLE dim_customer
    FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' IGNORE 1 LINES;
LOAD DATA LOCAL INFILE 'data/fact_quotations.csv' INTO TABLE fact_quotations
    FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' IGNORE 1 LINES;
LOAD DATA LOCAL INFILE 'data/fact_orders.csv' INTO TABLE fact_orders
    FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' IGNORE 1 LINES
    (order_id, @qid, order_date_key, customer_id, product_id, status_id, quantity_sheets,
     unit_price, discount_pct, gst_rate, net_amount, gst_amount, total_amount)
    SET quotation_id = NULLIF(@qid, '');

-- ---------- Indexes for reporting queries ----------
CREATE INDEX idx_orders_date     ON fact_orders (order_date_key);
CREATE INDEX idx_orders_customer ON fact_orders (customer_id);
CREATE INDEX idx_quotes_date     ON fact_quotations (quotation_date_key);

-- Quick row-count check (expected: 365 / 4 / 12 / 40 / 320 / 205)
SELECT 'dim_date' t, COUNT(*) n FROM dim_date UNION ALL
SELECT 'dim_status', COUNT(*) FROM dim_status UNION ALL
SELECT 'dim_product', COUNT(*) FROM dim_product UNION ALL
SELECT 'dim_customer', COUNT(*) FROM dim_customer UNION ALL
SELECT 'fact_quotations', COUNT(*) FROM fact_quotations UNION ALL
SELECT 'fact_orders', COUNT(*) FROM fact_orders;
