-- =====================================================================
-- Analysis queries (run after 01_schema_and_load.sql)
-- Revenue = net_amount (after discount, before GST), excluding Cancelled.
-- =====================================================================
USE sales_analytics;

-- Q1. Monthly revenue, orders and average order value
-- Skills: JOIN (3 tables), GROUP BY, aggregate functions
SELECT d.year, d.month_num, d.month_name,
       COUNT(*)                        AS orders,
       ROUND(SUM(o.net_amount), 2)     AS revenue,
       ROUND(AVG(o.net_amount), 2)     AS avg_order_value
FROM fact_orders o
JOIN dim_date   d ON d.date_key  = o.order_date_key
JOIN dim_status s ON s.status_id = o.status_id
WHERE s.status_name <> 'Cancelled'
GROUP BY d.year, d.month_num, d.month_name
ORDER BY d.year, d.month_num;

-- Q2. Revenue by material and thickness, with share of total
-- Skills: JOIN, GROUP BY, window function over aggregates
SELECT p.material, p.thickness_mm,
       SUM(o.quantity_sheets)                                   AS sheets_sold,
       ROUND(SUM(o.net_amount), 2)                              AS revenue,
       ROUND(100 * SUM(o.net_amount) / SUM(SUM(o.net_amount)) OVER (), 1) AS pct_of_total
FROM fact_orders o
JOIN dim_product p ON p.product_id = o.product_id
JOIN dim_status  s ON s.status_id  = o.status_id
WHERE s.status_name <> 'Cancelled'
GROUP BY p.material, p.thickness_mm
ORDER BY revenue DESC;

-- Q3. Top 5 customers by revenue (rank + share of total)
-- Skills: JOIN (3 tables), CTE, RANK() window function
WITH cust_rev AS (
    SELECT c.customer_id, c.customer_name, c.customer_type, c.city,
           COUNT(*)                    AS orders,
           SUM(o.net_amount)           AS revenue
    FROM fact_orders o
    JOIN dim_customer c ON c.customer_id = o.customer_id
    JOIN dim_status   s ON s.status_id   = o.status_id
    WHERE s.status_name <> 'Cancelled'
    GROUP BY c.customer_id, c.customer_name, c.customer_type, c.city
)
SELECT RANK() OVER (ORDER BY revenue DESC)            AS rnk,
       customer_name, customer_type, city, orders,
       ROUND(revenue, 2)                              AS revenue,
       ROUND(100 * revenue / SUM(revenue) OVER (), 1) AS pct_of_total
FROM cust_rev
ORDER BY rnk
LIMIT 5;

-- Q4. Quotation-to-order conversion rate by month
-- Skills: JOIN, conditional aggregation
SELECT d.year, d.month_num, d.month_name,
       COUNT(*)                                   AS quotations,
       SUM(q.converted_flag)                      AS converted,
       ROUND(100 * SUM(q.converted_flag) / COUNT(*), 1) AS conversion_pct
FROM fact_quotations q
JOIN dim_date d ON d.date_key = q.quotation_date_key
GROUP BY d.year, d.month_num, d.month_name
ORDER BY d.year, d.month_num;

-- Q5. Month-over-month revenue change
-- Skills: CTE, LAG() window function
WITH monthly AS (
    SELECT d.year, d.month_num, SUM(o.net_amount) AS revenue
    FROM fact_orders o
    JOIN dim_date   d ON d.date_key  = o.order_date_key
    JOIN dim_status s ON s.status_id = o.status_id
    WHERE s.status_name <> 'Cancelled'
    GROUP BY d.year, d.month_num
)
SELECT year, month_num,
       ROUND(revenue, 2) AS revenue,
       ROUND(LAG(revenue) OVER (ORDER BY year, month_num), 2) AS prev_month_revenue,
       ROUND(100 * (revenue - LAG(revenue) OVER (ORDER BY year, month_num))
             / LAG(revenue) OVER (ORDER BY year, month_num), 1) AS mom_change_pct
FROM monthly
ORDER BY year, month_num;

-- Q6. Cumulative (running) revenue by month
-- Skills: CTE, running total with SUM() OVER
WITH monthly AS (
    SELECT d.year, d.month_num, SUM(o.net_amount) AS revenue
    FROM fact_orders o
    JOIN dim_date   d ON d.date_key  = o.order_date_key
    JOIN dim_status s ON s.status_id = o.status_id
    WHERE s.status_name <> 'Cancelled'
    GROUP BY d.year, d.month_num
)
SELECT year, month_num, ROUND(revenue, 2) AS revenue,
       ROUND(SUM(revenue) OVER (PARTITION BY year ORDER BY month_num), 2) AS cumulative_revenue
FROM monthly
ORDER BY year, month_num;

-- Q7. Repeat customers: 4+ orders and above-average order value
-- Skills: GROUP BY ... HAVING, scalar subquery
SELECT c.customer_name, c.customer_type,
       COUNT(*)                    AS orders,
       ROUND(AVG(o.net_amount), 2) AS avg_order_value
FROM fact_orders o
JOIN dim_customer c ON c.customer_id = o.customer_id
JOIN dim_status   s ON s.status_id   = o.status_id
WHERE s.status_name <> 'Cancelled'
GROUP BY c.customer_id, c.customer_name, c.customer_type
HAVING COUNT(*) >= 4
   AND AVG(o.net_amount) > (SELECT AVG(net_amount) FROM fact_orders
                            WHERE status_id <> 4)
ORDER BY avg_order_value DESC;

-- Q8. Data validation checks (each should return 0 rows / 0)
-- Skills: data quality, reconciliation
-- (a) Amount arithmetic: net + GST must equal total (1 paisa rounding tolerance)
SELECT 'total_amount mismatch' AS check_name, COUNT(*) AS bad_rows
FROM fact_orders
WHERE ABS(net_amount + gst_amount - total_amount) > 0.01
UNION ALL
-- (b) Net amount must equal qty * price * (1 - discount)
SELECT 'net_amount mismatch', COUNT(*)
FROM fact_orders
WHERE ABS(quantity_sheets * unit_price * (1 - discount_pct / 100.0) - net_amount) > 0.01
UNION ALL
-- (c) Orders pointing to a quotation that does not exist
SELECT 'orphan quotation_id', COUNT(*)
FROM fact_orders o
LEFT JOIN fact_quotations q ON q.quotation_id = o.quotation_id
WHERE o.quotation_id IS NOT NULL AND q.quotation_id IS NULL
UNION ALL
-- (d) Quotation marked converted but no order exists
SELECT 'converted flag without order', COUNT(*)
FROM fact_quotations q
LEFT JOIN fact_orders o ON o.quotation_id = q.quotation_id
WHERE q.converted_flag = 1 AND o.order_id IS NULL
UNION ALL
-- (e) Order dated before its quotation
SELECT 'order before quotation', COUNT(*)
FROM fact_orders o
JOIN fact_quotations q ON q.quotation_id = o.quotation_id
WHERE o.order_date_key < q.quotation_date_key;
